/* ============================================================
   BATTERY LAB — Visor 3D interactivo
   Construido sobre Three.js. Representa la celda de forma
   esquemática pero fiel a su arquitectura real: colectores,
   electrodos, separador/electrolito y carcasa, con animación
   de flujo de electrones (circuito externo) y de iones
   (a través del electrolito).
   ============================================================ */

const Viewer3D = (() => {
  let scene, camera, renderer, controls, container;
  let modelGroup, tabAnodo, tabCatodo;
  let electronCurve, ionGaps = [];
  let electronParticles = [], ionParticles = [];
  let xrayOn = false, flowMode = 'descarga', flowSpeed = 1;
  let raycaster, mouseVec;
  let onInfoClick = null;
  let clock;
  let animId = null;

  const COLOR = {
    cobre: 0xC77B45, aluminio: 0xB9C2CC, niquel: 0xD8D3C4,
    grafito: 0x2E3238, sic: 0x3B4048, litioMetal: 0xC9CDD3, carbonoduro: 0x3a352c,
    lco: 0x3E5A8C, nmc: 0x4A6FA5, lfp: 0x3F7A5C, nca: 0x5A5A9B, sodio: 0x7A8C5C, azufre: 0xA6A03A,
    separador: 0xDDE3E8, electrolitoSolido: 0x8FD9E3,
    pouch: 0xB8BCC4, canAl: 0xC7CCD3, canSteel: 0x8A8F97, polymer: 0xEDE7DC,
    electron: 0xE3985E, ion: 0x4DD4E8
  };

  function colorAnodo(id) {
    return { grafito: COLOR.grafito, silicio_carbono: COLOR.sic, silicio_puro: COLOR.sic,
      litio_metalico: COLOR.litioMetal, carbono_duro: COLOR.carbonoduro, lto: 0x555b63 }[id] || COLOR.grafito;
  }
  function colorCatodo(id) {
    return { lco: COLOR.lco, nmc622: COLOR.nmc, nmc811: COLOR.nmc, lfp: COLOR.lfp,
      nca: COLOR.nca, sodio_np: COLOR.sodio, azufre: COLOR.azufre }[id] || COLOR.nmc;
  }
  function colorCarcasa(id) {
    return { bolsa_aluminio: COLOR.pouch, lata_aluminio: COLOR.canAl,
      lata_acero: COLOR.canSteel, polimero_rigido: COLOR.polymer }[id] || COLOR.pouch;
  }

  function init(containerEl, callbacks) {
    container = containerEl;
    onInfoClick = (callbacks && callbacks.onInfoClick) || null;
    clock = new THREE.Clock();

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(38, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.set(5.5, 4.2, 6.5);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.outputEncoding = THREE.sRGBEncoding;
    container.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 3;
    controls.maxDistance = 16;
    controls.target.set(0, 0, 0);

    const amb = new THREE.AmbientLight(0xffffff, 0.55);
    scene.add(amb);
    const key = new THREE.DirectionalLight(0xffffff, 0.9);
    key.position.set(6, 8, 4);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0x6ea8ff, 0.25);
    fill.position.set(-6, 2, -4);
    scene.add(fill);
    const rim = new THREE.DirectionalLight(0x4dd4e8, 0.3);
    rim.position.set(0, -3, -6);
    scene.add(rim);

    modelGroup = new THREE.Group();
    scene.add(modelGroup);

    raycaster = new THREE.Raycaster();
    mouseVec = new THREE.Vector2();
    renderer.domElement.addEventListener('click', onClick);

    window.addEventListener('resize', resize);
    animate();
  }

  function resize() {
    if (!container || !renderer) return;
    const w = container.clientWidth, h = container.clientHeight;
    if (w === 0 || h === 0) return;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }

  function clearGroup() {
    while (modelGroup.children.length) {
      const obj = modelGroup.children.pop();
      if (obj.geometry) obj.geometry.dispose();
      if (obj.material) {
        if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
        else obj.material.dispose();
      }
    }
    electronParticles = [];
    ionParticles = [];
    ionGaps = [];
  }

  function makeBox(w, h, d, color, opts) {
    opts = opts || {};
    const geo = new THREE.BoxGeometry(w, h, d);
    const mat = new THREE.MeshStandardMaterial({
      color, roughness: opts.roughness !== undefined ? opts.roughness : 0.55,
      metalness: opts.metalness !== undefined ? opts.metalness : 0.35,
      transparent: !!opts.transparent, opacity: opts.opacity !== undefined ? opts.opacity : 1
    });
    const mesh = new THREE.Mesh(geo, mat);
    if (opts.info) mesh.userData.info = opts.info;
    return mesh;
  }

  function addEdges(mesh, color) {
    const edges = new THREE.EdgesGeometry(mesh.geometry);
    const line = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: color || 0x000000, transparent: true, opacity: 0.25 }));
    mesh.add(line);
  }

  /* Reconstruye el modelo 3D a partir de config + resultados de simulación */
  function rebuild(config, r) {
    clearGroup();

    const W = 3.2, H = 0.42; // ancho y alto de referencia visual fijos (esquemático)
    const aspectRatio = config.anchoMm / config.largoMm;
    const depth = clamp(W * aspectRatio, 1.6, 2.6);

    const nVisual = Math.max(4, Math.min(10, Math.round(r.geometria.numCapas / 3)));
    const layerH = H / (nVisual * 2 + 1);
    const gapH = layerH * 0.35;
    const unitH = layerH * 2 + layerH * 0.28 * 2 + gapH; // altura de un bloque ánodo+colectores+separador+cátodo
    const totalStackH = unitH * nVisual;

    let y = -(totalStackH / 2);

    const infoAnodo = { titulo: r.materiales.anodo.nombre, texto: r.materiales.anodo.descripcion, tipo: 'Ánodo' };
    const infoCatodo = { titulo: r.materiales.catodo.nombre, texto: r.materiales.catodo.descripcion, tipo: 'Cátodo' };
    const infoSep = { titulo: r.materiales.separador.nombre, texto: r.materiales.separador.descripcion, tipo: 'Separador / electrolito' };
    const infoElectrolito = { titulo: r.materiales.electrolito.nombre, texto: r.materiales.electrolito.descripcion, tipo: 'Electrolito' };
    const infoColA = { titulo: r.materiales.colectorA.nombre, texto: r.materiales.colectorA.descripcion, tipo: 'Colector (ánodo)' };
    const infoColC = { titulo: r.materiales.colectorC.nombre, texto: r.materiales.colectorC.descripcion, tipo: 'Colector (cátodo)' };
    const infoCarcasa = { titulo: r.materiales.carcasa.nombre, texto: r.materiales.carcasa.descripcion, tipo: 'Carcasa' };

    for (let i = 0; i < nVisual; i++) {
      const anodoMesh = makeBox(W * 0.92, layerH, depth * 0.92, colorAnodo(r.materiales.anodo.id), { info: infoAnodo, roughness: 0.7, metalness: 0.1 });
      anodoMesh.position.y = y + layerH / 2; modelGroup.add(anodoMesh); addEdges(anodoMesh);
      y += layerH;

      const colAMesh = makeBox(W * 0.92, layerH * 0.28, depth * 0.92, COLOR.cobre, { info: infoColA, roughness: 0.35, metalness: 0.85 });
      colAMesh.position.y = y + (layerH * 0.28) / 2; modelGroup.add(colAMesh);
      y += layerH * 0.28;

      const gapY0 = y;
      const sepMesh = makeBox(W * 0.94, gapH, depth * 0.94, r.esSolido ? COLOR.electrolitoSolido : COLOR.separador,
        { info: r.esSolido ? infoSep : infoElectrolito, transparent: true, opacity: r.esSolido ? 0.55 : 0.38, roughness: 0.2, metalness: 0.05 });
      sepMesh.position.y = y + gapH / 2; modelGroup.add(sepMesh);
      ionGaps.push({ yCenter: sepMesh.position.y, halfW: W * 0.4, halfD: depth * 0.4 });
      y += gapH;

      const colCMesh = makeBox(W * 0.92, layerH * 0.28, depth * 0.92, COLOR.aluminio, { info: infoColC, roughness: 0.35, metalness: 0.85 });
      colCMesh.position.y = y + (layerH * 0.28) / 2; modelGroup.add(colCMesh);
      y += layerH * 0.28;

      const catodoMesh = makeBox(W * 0.92, layerH, depth * 0.92, colorCatodo(r.materiales.catodo.id), { info: infoCatodo, roughness: 0.6, metalness: 0.15 });
      catodoMesh.position.y = y + layerH / 2; modelGroup.add(catodoMesh); addEdges(catodoMesh);
      y += layerH;
    }

    /* Tabs de conexión (colectores salientes) */
    tabAnodo = makeBox(0.5, 0.09, 0.32, COLOR.cobre, { info: infoColA, metalness: 0.9, roughness: 0.25 });
    tabAnodo.position.set(-W / 2 - 0.22, totalStackH * 0.3, depth / 2 - 0.4);
    modelGroup.add(tabAnodo);

    tabCatodo = makeBox(0.5, 0.09, 0.32, COLOR.aluminio, { info: infoColC, metalness: 0.9, roughness: 0.25 });
    tabCatodo.position.set(W / 2 + 0.22, totalStackH * 0.3, depth / 2 - 0.4);
    modelGroup.add(tabCatodo);

    /* Carcasa envolvente */
    const casingH = totalStackH * 1.22;
    const carcasaMesh = makeBox(W * 1.08, casingH, depth * 1.1, colorCarcasa(r.materiales.carcasa.id),
      { info: infoCarcasa, transparent: true, opacity: xrayOn ? 0.12 : 0.9, roughness: 0.4, metalness: 0.5 });
    carcasaMesh.name = 'carcasa';
    modelGroup.add(carcasaMesh);
    addEdges(carcasaMesh, 0x000000);

    /* Curva del circuito externo (para el flujo de electrones) */
    const p0 = new THREE.Vector3(tabAnodo.position.x, tabAnodo.position.y, tabAnodo.position.z);
    const p2 = new THREE.Vector3(tabCatodo.position.x, tabCatodo.position.y, tabCatodo.position.z);
    const pMid = new THREE.Vector3(0, casingH * 2.2, depth / 2 - 0.4);
    electronCurve = new THREE.QuadraticBezierCurve3(p0, pMid, p2);


    const tubeGeo = new THREE.TubeGeometry(electronCurve, 24, 0.02, 8, false);
    const tubeMat = new THREE.MeshStandardMaterial({ color: COLOR.cobre, metalness: 0.7, roughness: 0.3 });
    const tube = new THREE.Mesh(tubeGeo, tubeMat);
    modelGroup.add(tube);

    /* Partículas de electrones (circuito externo) */
    const nElectrones = 8;
    for (let i = 0; i < nElectrones; i++) {
      const geo = new THREE.SphereGeometry(0.035, 10, 10);
      const mat = new THREE.MeshStandardMaterial({ color: COLOR.electron, emissive: COLOR.electron, emissiveIntensity: 0.7 });
      const sphere = new THREE.Mesh(geo, mat);
      sphere.userData.t = i / nElectrones;
      modelGroup.add(sphere);
      electronParticles.push(sphere);
    }

    /* Partículas de iones (a través del electrolito/separador) */
    ionGaps.forEach((gap, gi) => {
      const nIones = 5;
      for (let i = 0; i < nIones; i++) {
        const geo = new THREE.SphereGeometry(0.025, 8, 8);
        const mat = new THREE.MeshStandardMaterial({ color: COLOR.ion, emissive: COLOR.ion, emissiveIntensity: 0.8 });
        const sphere = new THREE.Mesh(geo, mat);
        sphere.userData.t = Math.random();
        sphere.userData.gap = gap;
        sphere.userData.lane = (Math.random() - 0.5) * gap.halfD * 1.4;
        modelGroup.add(sphere);
        ionParticles.push(sphere);
      }
    });

    fitCameraToModel(W, H, depth);
  }

  function fitCameraToModel(W, H, depth) {
    const dist = Math.max(W, depth) * 1.9 + 2;
    controls.minDistance = dist * 0.45;
    controls.maxDistance = dist * 2.6;
  }

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function setXray(on) {
    xrayOn = on;
    const carcasa = modelGroup.getObjectByName('carcasa');
    if (carcasa) carcasa.material.opacity = on ? 0.12 : 0.9;
  }

  function setFlowMode(mode) { flowMode = mode; } // 'carga' | 'descarga'
  function setFlowSpeed(v) { flowSpeed = v; }
  function setAutoRotate(on) {
    controls.autoRotate = on;
    controls.autoRotateSpeed = 2.2;
  }

  function onClick(event) {
    if (!onInfoClick) return;
    const rect = renderer.domElement.getBoundingClientRect();
    mouseVec.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouseVec.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouseVec, camera);
    const hits = raycaster.intersectObjects(modelGroup.children, false);
    for (const hit of hits) {
      if (hit.object.userData && hit.object.userData.info) {
        onInfoClick(hit.object.userData.info);
        return;
      }
    }
  }

  function animate() {
    animId = requestAnimationFrame(animate);
    const dt = clock.getDelta();
    const dir = flowMode === 'carga' ? -1 : 1;

    electronParticles.forEach((p, i) => {
      p.userData.t += dt * 0.18 * flowSpeed * dir;
      let t = p.userData.t % 1; if (t < 0) t += 1;
      const pos = electronCurve.getPoint(t);
      p.position.copy(pos);
    });

    ionParticles.forEach(p => {
      p.userData.t += dt * 0.35 * flowSpeed * (-dir);
      let t = p.userData.t % 1; if (t < 0) t += 1;
      const gap = p.userData.gap;
      p.position.set(p.userData.lane * 0 + (t - 0.5) * gap.halfW * 1.7, gap.yCenter, p.userData.lane);
    });

    controls.update();
    renderer.render(scene, camera);
  }

  function screenshot() {
    renderer.render(scene, camera);
    return renderer.domElement.toDataURL('image/png');
  }

  return { init, rebuild, resize, setXray, setFlowMode, setFlowSpeed, setAutoRotate, screenshot };
})();
